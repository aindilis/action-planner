rdf_save_as_prolog1(File):- open(File,write,Out),
				(	rdf(X,Y,literal(Z)),concat_atom([R,S],#,Y),concat_atom([A,B],#,X),
					format(Out, '~q.~n',[rdf(B,S,Z)]),
					fail
					; close(Out)
				).

rdf_save_as_prolog2(File):- open(File,append,Out),
				(	rdf(X,Y,Z),concat_atom([R,S],#,Y),concat_atom([A,B],#,X),concat_atom([F,G],#,Z),
					format(Out, '~q.~n',[rdf(B,S,G)]),
					fail
					; close(Out)
				).