rm instances.P
rm rdf.P
rm rdf.xwam
rm triples2.xwam
rm instances.xwam
rm triples.xwam
rm reasoner.xwam
rm rules.xwam
