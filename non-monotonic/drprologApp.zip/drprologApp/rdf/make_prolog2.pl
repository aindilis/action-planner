:- rdf_retractall(X,'http://www.w3.org/2000/01/rdf-schema#comment',Z).
:- rdf_save_as_prolog1('rdf/instances.P').
:- rdf_retractall(X,Y,literal(Z)).
:- rdf_save_as_prolog2('rdf/instances.P').
:- rdf_retractall(X,Y,Z).
:- halt.