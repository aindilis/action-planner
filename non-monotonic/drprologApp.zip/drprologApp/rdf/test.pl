fac(X,Y,Z):- rdf(X,Y,Z).



